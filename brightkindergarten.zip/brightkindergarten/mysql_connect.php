<?php

	$host = 'localhost';
	$user = 'root';
	$pass = '';

	$dbname = 'brightkindergarten'; 
	//connect to host
	$connect = mysql_connect($host, $user, $pass) or die(mysql_error());
	 
	//choose database to use
	$dbselect = mysql_select_db($dbname);

?>