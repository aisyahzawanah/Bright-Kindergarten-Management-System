-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 30, 2018 at 02:10 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brightkindergarten`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `IC` varchar(12) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_num` varchar(12) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `IC`, `email`, `phone_num`, `username`, `password`) VALUES
(1, 'Aisyah Zawanah', '951229145042', 'zawxnvh@gmail.com', '0172762403', 'zawanah', 'cumi'),
(2, 'nur syamimi', '980787678', 'mimi@gmail.com', '0178906547', 'mimi', 'mimi');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `ann_id` int(4) NOT NULL,
  `title` text NOT NULL,
  `post_date` date NOT NULL,
  `message` text NOT NULL,
  `post_by` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`ann_id`, `title`, `post_date`, `message`, `post_by`) VALUES
(1, 'Hari Raya Puasa', '2018-10-12', 'Selamat Hari Raya', 'Syamimi');

-- --------------------------------------------------------

--
-- Table structure for table `calendar_event`
--

CREATE TABLE `calendar_event` (
  `event_id` int(11) NOT NULL,
  `event_title` varchar(100) NOT NULL,
  `date_start` varchar(100) NOT NULL,
  `date_end` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `calendar_event`
--

INSERT INTO `calendar_event` (`event_id`, `event_title`, `date_start`, `date_end`) VALUES
(1, 'Teachers Days', '2018-10-03', '2018-10-04');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(5) NOT NULL,
  `class_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`) VALUES
(1, '4 T-REX'),
(2, '5 Cheerful'),
(3, '6 Fantastic');

-- --------------------------------------------------------

--
-- Table structure for table `exam_marks`
--

CREATE TABLE `exam_marks` (
  `exam_id` int(4) NOT NULL,
  `sub_id` int(4) NOT NULL,
  `class_id` int(4) NOT NULL,
  `stud_id` int(4) NOT NULL,
  `first_exam` double NOT NULL,
  `second_exam` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_marks`
--

INSERT INTO `exam_marks` (`exam_id`, `sub_id`, `class_id`, `stud_id`, `first_exam`, `second_exam`) VALUES
(53, 1, 1, 1, 79, 0),
(54, 2, 2, 2, 67.9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(5) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `type`) VALUES
(1, 'zawanah', 'cumi', 'admin'),
(2, 'aminah', 'aminah', 'teacher'),
(3, 'fatin', 'syahera', 'teacher'),
(4, 'eyra', 'jlo', 'teacher'),
(5, 'hafiz', 'hafiz', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stud_id` int(5) NOT NULL,
  `class_id` int(5) NOT NULL,
  `stud_name` varchar(100) NOT NULL,
  `stud_gender` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `BCN` varchar(50) NOT NULL,
  `guardian_name` varchar(100) NOT NULL,
  `guardian_phone_num` varchar(12) NOT NULL,
  `guardian_occupation` varchar(50) NOT NULL,
  `stud_address` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stud_id`, `class_id`, `stud_name`, `stud_gender`, `DOB`, `BCN`, `guardian_name`, `guardian_phone_num`, `guardian_occupation`, `stud_address`) VALUES
(1, 1, 'Nur Fariza Hourmain', 'F', '1995-07-17', 'NF457890', 'Hourmain', '0156702156', 'Doctor', '   Johor      '),
(2, 2, 'Nur Syamimi Samri', 'F', '2012-12-12', 'NS90178', 'Samri', '0198906752', 'Senior Engineer', 'Janda Baik, Pahang');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sub_id` int(5) NOT NULL,
  `sub_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`) VALUES
(1, 'Pendidikan Islam'),
(2, 'Bahasa Melayu'),
(3, 'English'),
(4, 'Mathematic');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `t_id` int(5) NOT NULL,
  `class_id` int(5) NOT NULL,
  `t_name` varchar(100) NOT NULL,
  `NRIC` varchar(14) NOT NULL,
  `t_section` varchar(10) NOT NULL,
  `t_email` varchar(50) NOT NULL,
  `t_phone` varchar(14) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`t_id`, `class_id`, `t_name`, `NRIC`, `t_section`, `t_email`, `t_phone`, `username`, `password`) VALUES
(1, 2, 'Siti Aminah', '691209019867', 'Evening', 'aminah@yahoo.com', '0198907865', 'aminah', 'aminah'),
(2, 2, 'Nur Fatin ', '967654115432', 'Evening', 'fatin@gmail.com', '0198765433', 'fatin', ''),
(3, 2, 'Nur Fatin ', '967654115432', 'Evening', 'fatin@gmail.com', '0198765433', 'fatin', ''),
(4, 2, 'haha', '967654115432', 'Evening', 'fatin@gmail.com', '0198765433', 'haha', ''),
(5, 2, 'hihi', '967654115432', 'Morning', 'hihi@gmail.com', '0198765433', 'hihi', 'hihi');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `upload_id` int(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`ann_id`);

--
-- Indexes for table `calendar_event`
--
ALTER TABLE `calendar_event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `exam_marks`
--
ALTER TABLE `exam_marks`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`upload_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `ann_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `calendar_event`
--
ALTER TABLE `calendar_event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `exam_marks`
--
ALTER TABLE `exam_marks`
  MODIFY `exam_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stud_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `sub_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `t_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `upload_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
