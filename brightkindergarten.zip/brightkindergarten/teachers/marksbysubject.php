<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>BRIGHT KINDERGARTEN MANAGEMENT SYSTEM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet"/>
  </head>
  
 <!--header -->		
 <div class="header">
   <div class="container">
     <div class="row">
       <div class="col-md-5">
         <!-- Logo -->
	 <div class="logo">
	    <h1><a href="home.php">Teacher</a></h1>
	 </div>
       </div>
		   
       <div class="collapse navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i></a>
                   <ul class="dropdown-menu">                               
                     <li>
                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                     </li>
                   </ul>
             </li>
          </ul>
      </div>
    </div>
  </div>
</div>
<!--End of header -->	

<!--Sidebar Nav -->
<div class="page-content">
  <div class="row">
    <div class="col-md-2">
      <div class="sidebar content-box" style="display: block;">		  
        <ul class="nav">
          <!-- Main menu -->
          <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
          <li><a href="calendar.php"><i class="glyphicon glyphicon-calendar"></i> Calendar </a></li>
 	  <li class='submenu'>
 	    <a href='#'><i class="glyphicon glyphicon-cog"></i> Profile <span class="caret pull-right"></span></a>
 	     <ul>
 		<li><a href="profile.php?"> My Profile </a></li>
 		<li><a href="change_password.php"> Change Password </a></li>
 	     </ul>
 	  </li>
				 
	  <li class='submenu'>
	    <a href='#'><i></i> Student Marks <span class="caret pull-right"></span></a>
	      <ul>
		<li><a href="insert_marks.php"> Insert Marks </a></li>
		<li><a href="marksbysubject.php"> View Marks </a></li>
	      </ul>
	  </li>
	  
	  <li><a href="timetable.php"><i class="glyphicon glyphicon-pencil"></i> Timetable </a></li>
	  
	  <li><a href="student_class.php"><span> Students' Information </span></a></li>
	  		
      </ul>
    </div>
  </div>
  <!--End Of Sidebar Nav -->
  
  <body>
    <div class="row">
      <div class="col-md-9">
        <div class="content-box-large">
	  <div class="panel-heading">
	    <div class="panel-title"> VIEW STUDENTS MARKS ACCORDING TO SUBJECT </div>
	  </div>
	  <div class="panel-body">
	    <form method="post">
	      <table class="table">
	        <tbody>
		<?php
		$user_query = mysql_query("select * from subject")or die(mysql_error());
		while($row = mysql_fetch_array($user_query))
		{
		      $id = $row['sub_id'];
		?>
				     									
		<tr>
		  <td width="30"></td>
		  <td><strong><?php echo $row['sub_name']; ?><strong></td>
		  <td class="col-md-1">
			<center><a button class="btn btn-success" title="Click here to View." href="view_marks.php<?php echo '?id='.$row['sub_id'];?>">View Student Marks</a></center>
		  </td>
		</tr>
		<?php } ?>
	       </tbody>
	   </table>
	 </form>
	</div>
       </div>
      </div>
     </div>
    </div>
   </div>

<?php include('script.php'); ?>

<br/><br/><br/>

<!-- Footer --> 
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>
<!-- End Of Footer --> 
    
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../design/bootstrap/js/bootstrap.min.js"></script>
<script src="../design/js/custom.js"></script>
 
</body>
</html>		  
		  
	 