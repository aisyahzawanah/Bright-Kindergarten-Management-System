<?php
include('mysql_connect.php');
include('check_login.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>BRIGHT KINDERGARTEN MANAGEMENT SYSTEM</title>
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">
   <link href="../design/css/bootstrap.min.css" rel="stylesheet"/>
   <link href="../design/css/style.css" rel="stylesheet"/>
   <link href="../design/css/alert.css" rel="stylesheet"/>
   
  </head>
  
 <div class="header">
   <div class="container">
     <div class="row">
       <div class="col-md-5">
         <!-- Logo -->
	 <div class="logo">
	    <h1><a href="home.php">Teacher</a></h1>
	 </div>
       </div>
		   
       <div class="collapse navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['t_username'] ?> <i class="caret"></i></a>
                   <ul class="dropdown-menu">                               
                     <li>
                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                     </li>
                   </ul>
             </li>
          </ul>
      </div>
    </div>
  </div>
</div>

<div class="page-content">
  <div class="row">
    <div class="col-md-2">
      <div class="sidebar content-box" style="display: block;">		  
        <ul class="nav">
          <!-- Main menu -->
          <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
          <li><a href="calendar.php"><i class="glyphicon glyphicon-calendar"></i> Calendar </a></li>
 	  <li class='submenu'>
 	    <a href='#'><i class="glyphicon glyphicon-cog"></i> Profile <span class="caret pull-right"></span></a>
 	     <ul>
 		<li><a href="profile.php?"> My Profile </a></li>
 		<li><a href="change_password.php"> Change Password </a></li>
 	     </ul>
 	  </li>
			 
	  <li class='submenu'>
	    <a href='#'><i></i> Student Marks <span class="caret pull-right"></span></a>
	      <ul>
		<li><a href="insert_marks.php"> Insert Marks </a></li>
		<li><a href="marksbysubject.php"> View Marks </a></li>
	      </ul>
	  </li>
	  
	  <li><a href="timetable.php"><i class="glyphicon glyphicon-pencil"></i> Timetable </a></li>
	   
	  <li><a href="student_class.php"><span> Students' Information </span></a></li>
	  		
      </ul>
    </div>
  </div>
  <body>
	    
	<div class="row">
	   <div class="col-md-9">
	      <div class="content-box-large">
		 <div class="panel-heading">
		    	<center><b><div class="panel-title"> PRINT STUDENTS INFORMATION </div></b></center>
		 </div>
		 
		   <form method="post">
		   <div class="panel-body">
		        <table class="table table-bordered">
		    	   <thead>
		    		<tr>
				       <th>Class</th>
		    		   <th>Name</th>
		    		   <th>Gender</th>
		    		   <th>Birth Date</th>
		    		   <th>Birth Certificate Number</th>
				       <th>Guardian Name</th>
				       <th>Guardian Phone No.</th>
				       <th>Guardian Occupation</th>
				       <th>Address</th>    
		    		</tr>
				<script>
				$(function() 
				{
				});
				</script>
		    	   </thead>
				  
	                    <?php 
			    $query=mysql_query("select * FROM student, class where student.class_id=class.class_id AND class.class_id=class.class_id")or die(mysql_error());
			    while($rec=mysql_fetch_array($query)){
			    ?>
			    <tr class="edit_tr">
			    <td><?php echo $rec['class_name']; ?></td>
			    <td><?php echo $rec['stud_name']; ?></td>
			    <td><?php echo $rec['stud_gender'] ?></td>
			    <td><?php echo $rec['DOB'] ?></td>
			    <td><?php echo $rec['BCN'] ?></td>
			    <td><?php echo $rec['guardian_name'] ?></td>
			    <td><?php echo $rec['guardian_phone_num'] ?></td>
			    <td><?php echo $rec['guardian_occupation'] ?></td>
			    <td><?php echo $rec['stud_address'] ?></td>
			    </tr><?php }?>
		      </table>
		  </div>
   	      </form>
		 
	    <div class="empty">
		 <a href="#" class="btn btn-primary" onclick="window.print()" id="print" ><i class="fa fa-print"></i> Cetak Logs </a></button>
	   </div>
	   	 
	      </div>
	     </div>
	</div>
    </div>
</div>
				  
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>

      <link href="../design/vendors/datatables/dataTables.bootstrap.css" rel="stylesheet" media="screen">

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>

    <script src="../design/vendors/datatables/js/jquery.dataTables.min.js"></script>

    <script src="../design/vendors/datatables/dataTables.bootstrap.js"></script>

    <script src="../design/js/custom.js"></script>
    <script src="../design/js/tables.js"></script>
  </body>
</html>