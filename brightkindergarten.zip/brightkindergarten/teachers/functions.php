<?php

require("mysql_connect.php");

function getUsersData($t_id)
{
	$array = array();
	$q = mysql_query("SELECT * FROM teacher WHERE `t_id`=".$t_id);
	while($r = mysql_fetch_assoc($q))
	{
		$array['t_id'] = $r['t_id'];
		$array['t_name'] = $r['t_name'];
		$array['NRIC'] = $r['NRIC'];
		$array['t_section'] = $r['t_section'];
		$array['t_email'] = $r['t_email'];
		$array['t_phone'] = $r['t_phone'];
		$array['username'] = $r['username'];
	}
	return $array;
}

function getId($username)
{
	$q = mysql_query("SELECT `t_id` FROM `teacher` WHERE `username`='".$username."'");
	while($r = mysql_fetch_assoc($q))
	{
		return $r['t_id'];
	}
}

function updateProfile ($t_id, $t_name, $t_email, $t_phone)
{
	if(mysql_query("UPDATE teacher SET `t_name`='".$t_name."', `t_email`='".$t_email."', `t_phone`='".$t_phone."' WHERE `t_id`=".$t_id))
	  return true;
	else
	  return false;
}
?>