<?php
session_start();

if (!empty($_SESSION['t_username'])) 
{
    header('location:home.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="free-educational-responsive-web-template-webEdu">
	<meta name="author" content="webThemez.com">
	<title>BRIGHT KINDERGARTEN MANAGEMENT SYSTEM</title>
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="../index/css/bootstrap.min.css">
	<link rel="stylesheet" href="../index/css/font-awesome.min.css"> 
	<link rel="stylesheet" href="../index/css/bootstrap-theme.css" media="screen"> 
	<link rel="stylesheet" href="../index/css/style.css">
        <link rel='stylesheet' id='camera-css'  href='../index/css/camera.css' type='text/css' media='all'> 

</head>
<body>

<!-- Fixed navbar -->
<div class="navbar navbar-inverse">
  <div class="container">
    <div class="navbar-header">
      <!-- Button for smallest screens -->
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        <a class="navbar-brand" href="../index.html">
	  <img src="../index/images/logos.png" /></a>
    </div>
    
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav pull-right mainNav">
	<li><a href="../index.html">Homepage</a></li>
	<li><a href="../about.html">About</a></li>
	<li><a href="../contact.html">Contact Us</a></li>
	<li class="dropdown-active">
	  <a href="#" class="dropdown-toggle" data-toggle="dropdown"> Login <b class="caret"></b></a>
	     <ul class="dropdown-menu">
		<li><a href="../admin/login.php">Admin</a></li>
		<li><a href="login.php">Teacher</a></li>
	     </ul>
	</li>	
      </ul>
    </div>
   <!--/.nav-collapse -->
  </div>
</div>
<!-- /.navbar -->

<header id="head" class="secondary">
<div class="container">
<h1>LOGIN</h1>
</div>
</header>

<!-- container -->	
<div class="container">
  <div class="row">
    <div class="col-md-8">
      <h3 class="section-title">Login</h3>
	<form class="form-light mt-20" role="form" action="auto.php" method="POST">
	  <div class="form-group">
	    <label>Username</label>
	    <input type="text" class="form-control" name="t_username" placeholder="username" />
	  </div>
	  <div class="form-group">
	    <label>Password</label>
	    <input type="password" name="t_password" class="form-control" name="password" placeholder="password" />
	  </div>	  
         <button class="btn btn-two" type="submit" name="submit" value="true" >Login</button><p><br/></p>
					
			     <?php
			     
			     //php code we use to display the error message
			     if (!empty($_GET['error'])) 
			     {
				if ($_GET['error'] == 1) 
				{
				    print '<script type="text/javascript">'; 
				    print 'alert("Username and Password not been filled!")'; 
				    print '</script>';  
				} 
				else if ($_GET['error'] == 2) 
				{
				    echo '<h2 align="center">Username not been filled!</h2>';
				} 
				else if ($_GET['error'] == 3) 
				{
				    echo '<h2 align="center">Password not been filled!</h2>';
				} 
			        else if ($_GET['error'] == 4) 
				{
				    echo '<h2 align="center">Username and Password is not registered!</h2>';
			        }
			     }
			     ?>
    </form>
   </div>
  </div>
</div>

    <div class="social text-center">
       <a href="https://www.facebook.com/kafa.ibtidaiyyah?fref=ts"><i class="fa fa-facebook"></i></a>
    </div>

    <div class="clear"></div><!--CLEAR FLOATS-->
		     
<div class="footer2">
  <div class="container">
    <div class="row">
      <div class="col-md-6 panel">
        <div class="panel-body">
	   <p class="simplenav">
	     <a href="../index.html">Homepage</a> | 
	     <a href="../about.html">About</a> |
	     <a href="../contact.html">Contact Us</a>
	   </p>
	</div>
    </div>

    <div class="col-md-6 panel">
      <div class="panel-body">
	<p class="text-right">
	   Copyright &copy; 2018 Bright Kindergarten
	</p>
       </div>
     </div>
   </div>
   
 <!-- /row of panels -->
 </div>
</div>

</footer>

<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
<script src="../index/js/modernizr-latest.js"></script> 
<script type='text/javascript' src='../index/js/jquery.min.js'></script>
<script type='text/javascript' src='../index/js/fancybox/jquery.fancybox.pack.js'></script>
    
<script type='text/javascript' src='../index/js/jquery.mobile.customized.min.js'></script>
<script type='text/javascript' src='../index/js/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='../index/js/camera.min.js'></script> 
<script src="../index/js/bootstrap.min.js"></script> 
<script src="../index/js/custom.js"></script>

<script>
jQuery(function()
{
   jQuery('#camera_wrap_4').camera
   ({
        transPeriod: 500,
        time: 3000,
        height: '600',
        loader: 'false',
        pagination: true,
        thumbnails: false,
        hover: false, 
        playPause: false,
        navigation: false,
        opacityOnGrid: false,
        imagePath: 'images/'
   });
});
</script>
    
</body>
</html>
