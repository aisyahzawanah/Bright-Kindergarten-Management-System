<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>BRIGHT KINDERGARTEN MANAGEMENT SYSTEM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet" />
  </head>
		
 <div class="header">
   <div class="container">
     <div class="row">
       <div class="col-md-5">
         <!-- Logo -->
	 <div class="logo">
	    <h1><a href="home.php">Teacher</a></h1>
	 </div>
       </div>
		   
       <div class="collapse navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i></a>
                   <ul class="dropdown-menu">                               
                     <li>
                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                     </li>
                   </ul>
             </li>
          </ul>
      </div>
    </div>
  </div>
</div>

<div class="page-content">
  <div class="row">
    <div class="col-md-2">
      <div class="sidebar content-box" style="display: block;">		  
        <ul class="nav">
          <!-- Main menu -->
          <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
          <li><a href="calendar.php"><i class="glyphicon glyphicon-calendar"></i> Calendar </a></li>
 	  <li class='submenu'>
 	    <a href='#'><i class="glyphicon glyphicon-cog"></i> Profile <span class="caret pull-right"></span></a>
 	     <ul>
 		<li><a href="profile.php?"> My Profile </a></li>
 		<li><a href="change_password.php"> Change Password </a></li>
 	     </ul>
 	  </li>
			 
	  <li class='submenu'>
	    <a href='#'><i></i> Student Marks <span class="caret pull-right"></span></a>
	      <ul>
		<li><a href="insert_marks.php"> Insert Marks </a></li>
		<li><a href="marksbysubject.php"> View Marks </a></li>
	      </ul>
	  </li>
	  
	  <li><a href="timetable.php"><i class="glyphicon glyphicon-pencil"></i> Timetable </a></li>
	  
	  <li><a href="student_class.php"><span> Students' Information </span></a></li>
	  		
      </ul>
    </div>
  </div>
  <body>
	 
	<div class="row">
	     <div class="col-md-9">
	      	<div class="content-box-large">
	    	    <div class="panel-heading">
	    	    	   <?php
	    	    	   $id = $_GET['id'];
	    	    	   $user_query = mysql_query("select * from subject where sub_id=$id")or die(mysql_error());
	    	    	   while($row = mysql_fetch_array($user_query))
	    	    	   {
	    	    	  	$id = $row['sub_id'];
	    	    	  	$sub_name = $row['sub_name'];
	    	    	   }
	    	    	   ?>
	    	    	   <center><div class="panel-title"><strong>Subject Marks&nbsp;<?php echo $sub_name; ?></strong></div></center>
	    	    </div>
			
		<div class="row-fluid">
		<?php	
		$count_client=mysql_query("select * from exam_marks");
		$count = mysql_num_rows($count_client);
		?>
			
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		   <div class="modal-dialog">
		      <div class="modal-content">
			   <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Confirmation</h4>
			   </div>
			  <div class="modal-body">
				Are you to sure you want to delete this?
			  </div>
			  <div class="modal-footer">
			  <form method = "POST">
			      <input type="submit" name="delete" value = "Delete" class="btn btn-danger">
				    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			   </div>
			</div>
		     </div>
		</div>
		<?php
		if(isset($_POST['delete']))
		{
		    $id=$_POST['selector'];
		    $N = count($id);
		    for($i=0; $i < $N; $i++)
		    {
			$result = mysql_query("DELETE FROM exam_marks where exam_id='$id[$i]'");
		    }
		}
		?>
		
		<!-- block -->						
	        <div id="block_bg" class="block">	
		    <div class="navbar navbar-inner block-header">
			<br/>
			&nbsp;&nbsp;&nbsp;<button type='button' class="btn btn-danger" data-toggle='modal' data-target='#myModal'><i class="glyphicon glyphicon-trash"></i></button>
				<a button type='button' class="btn btn-primary" href="marksbysubject.php">Back</a>
		   </div>
			
	    	    <div class="panel-body">
			<form method="post">
	    		<table class="table">
	    		<thead>
	    		   <tr>
	    		     <th></th>
			     <th><center>Class</center></th>
			     <th><center>Subject</center></th>				 				 
	    		     <th><center>Student Name</center></th>
	    		     <th><center>Exam 1</center></th>
	    		     <th><center>Exam 2</center></th>
	    		     <th><center>Action</center></th>
	    		     <script src="../js/jquery.dataTables.min.js"></script>
	    		     <script src="../js/DT_bootstrap.js"></script>
	    		     <th></th>
	    		   </tr>
	    		</thead>
	    		   <tbody> 
		   
			       <?php 
			       $id=$_GET['id'];
			       $query=mysql_query("SELECT * FROM exam_marks INNER JOIN class ON exam_marks.class_id = class.class_id 
			       			   INNER JOIN subject ON exam_marks.sub_id = subject.sub_id 
			       			  LEFT JOIN student ON exam_marks.stud_id = student.stud_id WHERE subject.sub_id = $id")or die(mysql_error());
			       	  while($row=mysql_fetch_array($query))
				  {
				      $id = $row['exam_id'];		     
			       ?>
			       
			    <tr>
				<td width="30">
				<input id="optionsCheckbox" class="uniform_on" name="selector[]" type="checkbox" value="<?php echo $id; ?>" />
				</td>
				<td><center><?php echo $row['class_name']; ?></center></td>
				<td><center><?php echo $row['sub_name']; ?></center></td>				
				<td><center><?php echo $row['stud_name']; ?></center></td>				
				<td><center><?php echo $row['first_exam']; ?></center></td>
				<td><center><?php echo $row['second_exam']; ?></center></td>
				<td class="col-md-1">
				<center><a href="edit_exam.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i class="glyphicon glyphicon-pencil"></i></a>
				</center>
			     </tr>
			     
			     <?php } ?>
			  </tbody>
		</table>	
	      </form>			       
	    </div>
          </div> 
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('script.php'); ?>

<br/><br/><br/>
       
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>
       
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../design/bootstrap/js/bootstrap.min.js"></script>
<script src="../design/js/custom.js"></script>
       
</body>
</html>		  
		  
		  