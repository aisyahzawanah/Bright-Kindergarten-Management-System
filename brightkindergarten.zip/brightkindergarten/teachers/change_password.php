<?php
include('check_login.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>BRIGHT KINDERGARTEN MANAGEMENT SYSTEM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">

  </head>
		
 <div class="header">
   <div class="container">
     <div class="row">
       <div class="col-md-5">
         <!-- Logo -->
	 <div class="logo">
	    <h1><a href="home.php">Teacher</a></h1>
	 </div>
       </div>
		   
       <div class="collapse navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i></a>
                   <ul class="dropdown-menu">                               
                     <li>
                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                     </li>
                   </ul>
             </li>
          </ul>
      </div>
    </div>
  </div>
</div>

<div class="page-content">
  <div class="row">
    <div class="col-md-2">
      <div class="sidebar content-box" style="display: block;">		  
        <ul class="nav">
          <!-- Main menu -->
          <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
          <li><a href="calendar.php"><i class="glyphicon glyphicon-calendar"></i> Calendar </a></li>
 	  <li class='submenu'>
 	    <a href='#'><i class="glyphicon glyphicon-cog"></i> Profile <span class="caret pull-right"></span></a>
 	     <ul>
 		<li><a href="profile.php?"> My Profile </a></li>
 		<li><a href="change_password.php"> Change Password </a></li>
 	     </ul>
 	  </li>
	  					 
	  <li class='submenu'>
	    <a href='#'><i></i> Student Marks <span class="caret pull-right"></span></a>
	      <ul>
		<li><a href="insert_marks.php"> Insert Marks </a></li>
		<li><a href="marksbysubject.php"> View Marks </a></li>
	      </ul>
	  </li>
	  
	  <li><a href="timetable.php"><i class="glyphicon glyphicon-pencil"></i> Timetable </a></li>
	  
	  <li><a href="student_class.php"><span> Students' Information </span></a></li>
	  		
      </ul>
    </div>
  </div>
  <body>
	
	<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title"> CHANGE PASSWORD </div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		 

<?php

   $page_title = 'Change User Password';
   
   //Check for form submission
   if(isset($_POST['submitted']))
   {
        require_once('connect.php'); //connect to the database
	
	function escape_data($data)
	{
		global $dbc;
		if(ini_get('magic_quotes_gpc'))
		{
			$data = stripslashes($data);
		}
		return mysql_real_escape_string(trim($data), $dbc);
	}
	
	$errors= array ();
	
	//Check for an email address
	if(empty($_POST['t_email']))
	{
	    $errors[] = 'You forgot to enter your email ';
	}
	else
	{
	    $e = escape_data($_POST['t_email']);
	}
	
	//Check for the current password
	if(empty($_POST['t_password']))
	{
	    $errors[] = 'You forgot to enter your current password';
	}
	else
	{
	    $p = escape_data($_POST['t_password']);
	}
	
	//Check for a new password and match
	if(!empty($_POST['t_Password1']))
	{
	    if($_POST['t_Password1'] != $_POST['t_Password2'])
	    {
	       $errors[] = 'Your new password did not match the confirmed password.';
	    }
	    else
	    {
	       $np = escape_data($_POST['t_Password1']);
	    }
	}
	else
	{
	    $errors[] = 'You forgot to enter your new password.';
	}
	
	if(empty($errors)) //If everything's OK
	{
	    //Check that they've entered the right email address/password combination
	    $query = "SELECT t_id FROM teacher WHERE (t_email='$e' AND t_password='$p')";
	    $result = mysql_query($query);
	    $num = mysql_num_rows($result);
	    
	    if(mysql_num_rows($result) == 1 ) //Match was made
	    {
	        //Get the cust_id
		$row = mysql_fetch_array($result, MYSQL_NUM);
		
		//Make the UPDATE query
		$query = "UPDATE teacher SET t_password='$np' WHERE t_id = $row[0]";
		$result = @mysql_query($query);
		
		if(mysql_affected_rows() == 1) //If it ran OK
		{
		   //Print a message
		   echo '<h1>Thank You</h1>
		         <p>Your password has been updated. </p><p><br/></p>';
			exit();
		}
		else //If it did not run OK
		{
		   //Public message
		   echo '<h1>System Error</h1>
		        <p class = "error"> Your password could not be changed due to a system error. We apologize for any inconvenience.</p>';
			
		   //Debugging message
		   echo '<p>' . mysql_error() . '<br/><br/>Query: ' . $query . '</p>';
		   exit();
	    }
	    }
	    else //Invalid email address/password combination
	    {
	        echo '<h1>Error!</h1>
		      <p class = "error"> The email address and password do not match those on file. </p>';
	    }
	 } 
	{
	    echo '<h1>Error!</h1>
		  <p class = "error"> The following error(s) occurred:<br/>';
	    foreach($errors as $msg) //Print each error
	    {
		  echo " - $msg <br/>\n";
	    }
		
	     echo '</p><p>Please try again</p><p><br/></p>';
	} //End of if (empty($errors)) IF
	    
	    mysql_close(); //Close database connection
        }

?>		 		 	 		 	 
		 
		    <form class="form-horizontal" method="post" action="change_password.php">
		    <fieldset>		    						    
					    
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">E-mail</label>
			      <div class="col-md-10">
				<input class="form-control" id = "email"  name="t_email" type="text" placeholder="Email" required autocomplete="off" value="<?php if(isset($_POST['t_email'])) echo $_POST['t_email']; ?>" />
			      </div>
			</div>					    					
									
			<div class="form-group">
			    <label class="col-md-2 control-label" for="text-field"> Current Password </label>
				<div class="col-md-10">
				    <input class="form-control" id ="password"  name="t_password" type="password" placeholder="Current Password" required autocomplete="off" />
				</div>
			</div>
			
			<div class="form-group">
			    <label class="col-md-2 control-label" for="text-field"> New Password </label>
				<div class="col-md-10">
				    <input class="form-control" id ="password"  name="t_Password1" type="password" placeholder="New Password" required autocomplete="off" />
				</div>
			</div>	
			
			<div class="form-group">
			    <label class="col-md-2 control-label" for="text-field"> Confirmation Password </label>
				<div class="col-md-10">
				    <input class="form-control" id ="password"  name="t_Password2" type="password" placeholder="Confirm Password" required autocomplete="off" />
				</div>
			</div>												    						    
				    
           		<div class="form-group">
                           <div class="col-lg-6">
                               <center><button class="btn btn-success" type="hidden" name="submitted" value="true">Change Password</button></center>
                           </div>                
                       </div>
		       </fieldset>
		    </form>
	       </div>
	   </div>
       </div>
    </div>
   </div>
</div>

<?php include('script.php'); ?>    

<br/><br/><br/>

<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>


   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
</body>
</html>	
		    
		   		    	