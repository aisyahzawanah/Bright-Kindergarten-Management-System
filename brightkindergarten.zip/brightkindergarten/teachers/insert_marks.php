<?php
include('check_login.php');
include('mysql_connect.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>BRIGHT KINDERGARTEN MANAGEMENT SYSTEM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">
    <script type="text/javascript" src="../design/jquery-1.10.2.min.js"></script>
         
  </head>
  
 <div class="header">
   <div class="container">
     <div class="row">
       <div class="col-md-5">
         <!-- Logo -->
	 <div class="logo">
	    <h1><a href="home.php">Teacher</a></h1>
	 </div>
       </div>
		   
       <div class="collapse navbar-collapse">
         <ul class="nav navbar-nav navbar-right">
            <li class="dropdown">
                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i></a>
                   <ul class="dropdown-menu">                               
                     <li>
                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                     </li>
                   </ul>
             </li>
          </ul>
      </div>
    </div>
  </div>
</div>

<div class="page-content">
  <div class="row">
    <div class="col-md-2">
      <div class="sidebar content-box" style="display: block;">		  
        <ul class="nav">
          <!-- Main menu -->
          <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
          <li><a href="calendar.php"><i class="glyphicon glyphicon-calendar"></i> Calendar </a></li>
 	  <li class='submenu'>
 	    <a href='#'><i class="glyphicon glyphicon-cog"></i> Profile <span class="caret pull-right"></span></a>
 	     <ul>
 		<li><a href="profile.php?"> My Profile </a></li>
 		<li><a href="change_password.php"> Change Password </a></li>
 	     </ul>
 	  </li>
				 
	  <li class='submenu'>
	    <a href='#'><i></i> Student Marks <span class="caret pull-right"></span></a>
	      <ul>
		<li><a href="insert_marks.php"> Insert Marks </a></li>
		<li><a href="marksbysubject.php"> View Marks </a></li>
	      </ul>
	  </li>
	  
	  <li><a href="timetable.php"><i class="glyphicon glyphicon-pencil"></i> Timetable </a></li>
	  
	  <li><a href="student_class.php"><span> Students' Information </span></a></li>
	  		
      </ul>
    </div>
  </div>
  <body>

	<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title">INSERT STUDENT MARKS</div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		    <form class="form-horizontal" role="form" method="post">

		       <div class="form-group">
		         <label class="col-md-1 control-label" for="text-field">Subject</label>
		       		<div class="col-md-10">
		       		<div class="bfh-selectbox" data-name="selectbox3" data-value="12" data-filter="true">
		       		<div data-value="1">
		       		   <select id="sub_id" name="sub_id" class="form-control" required>
		       		   	<option></option>
		       		   	<?php 
		       		   	$query=mysql_query("select * from subject");
		       		   	while($row=mysql_fetch_array($query))
		       		   	{ ?>
		       		   	<option value="<?php echo $row['sub_id'];?>"> <?php echo $row['sub_name'];?> </option>
		       		   	<?php } ?>
		       		   </select>	
		       		</div>				
		       		</div>
			      </div>
			</div>	

		       <div class="form-group">
		         <label class="col-md-1 control-label" for="text-field">Class</label>
		       		<div class="col-md-10">
		       		<div class="bfh-selectbox" data-name="selectbox3" data-value="12" data-filter="true">
		       		<div data-value="1">
		       		   <select id="class_id" name="class_id" class="form-control" required />
		       		   	<option></option>
		       		   	<?php 
		       		   	$query=mysql_query("select * from class");
		       		   	while($row=mysql_fetch_array($query))
		       		   	{ ?>
		       		   	<option value="<?php echo $row['class_id'];?>"> <?php echo $row['class_name'];?> </option>
		       		   	<?php } ?>
		       		   </select>					  	
		       		</div>				
		       		</div>
			      </div>
			</div>						
			
			<br/><br/><br/><br/>
			
			<div id="block_bg" class="block">	
		          <div class="navbar navbar-inner block-header">
			    <div class="block-content collapse in">
			      <div class="span12">
			      
			      <div class="table-responsive">
			        <table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
			      	  <thead>
			      	    <tr>			      	    
			      		<th width="300"><center> Student Name </center></th>
			      		<th width="200"><center> Exam 1 </center></th>
			      		<th width="200"><center> Exam 2</center></th>
			      	     </tr>
			      	 </thead>
			      	<tbody>

				<tr class="edit_tr">				
				<td width="300"><center>
				  <div class="bfh-selectbox" data-name="selectbox3" data-value="12" data-filter="true">
				    <div data-value="1">
				      <select id="stud_id" name="stud_id" class="form-control" required />
				        <option></option>
				        <?php 
				        $query=mysql_query("select * from student");
				        while($row=mysql_fetch_array($query))
				        { ?>
				        <option value="<?php echo $row['stud_id'];?>"> <?php echo $row['stud_name'];?> </option>
				        <?php } ?>
				      </select>	
				     </div>				
				    </div>
				 </center>
				</td>
						
				<td width="100"><input type='text' class="form-control input-md" id = "first_exam"  name="first_exam" /></td>
				<td width="100"><input type='text' class="form-control input-md" id = "second_exam"  name="second_exam" /></td>
				</tr>
				
				</tbody>
			      </table>
			      <br/>
		
			      <div class="btn-group pull-right col 2">	     
			       	  <button class="btn btn-success" type="submit" name="insert">Add Student Marks</button>
			      </div>
	
			      <div class="btn-group pull-right">
				   &nbsp; &nbsp; 
			      	   <button class="btn btn-danger" type="reset" name="reset">Clear Fields</button>
			     </div>		        
	            </div>
	          </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
 
<?php
	if (isset($_POST['insert']))
	{
	$sub_id=$_POST['sub_id'];
	$class_id=$_POST['class_id'];	
	$stud_id=$_POST['stud_id'];		
	$first_exam=$_POST['first_exam'];
	$second_exam=$_POST['second_exam'];

	mysql_query("insert into exam_marks (exam_id, sub_id, class_id,  stud_id, first_exam, second_exam) values 
	('', '$sub_id', '$class_id','$stud_id','$first_exam','$second_exam')")or die(mysql_error());
?>

<?php 
$query=mysql_query("SELECT * FROM exam_marks")or die(mysql_error());
while($rec=mysql_fetch_array($query))
{

$id = $rec['sub_id'];

}?>

<script>
alert('Succsessfully Save');
window.location = "view_marks.php?id=<?php echo $id;?>";
</script>
<?php
}?>

<footer>
  <div class="container">
    <div class="copy text-center">
        Copyright &copy; 2018 Bright Kindergarten </a>
     </div>
   </div>
</footer>

   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
</body>
</html>	
			