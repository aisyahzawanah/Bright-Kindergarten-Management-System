<?php
include('mysql_connect.php');
 
session_start();
 
//Accept data from login.php
$t_username = $_POST['t_username'];
$t_password = $_POST['t_password'];
 
//to prevent sql injection
//we use mysql_real_escape_string
$t_username = mysql_real_escape_string($t_username);
$t_password = mysql_real_escape_string($t_password);
 
//check the data sent, whether empty or not
if (empty($t_username) && empty($t_password)) {
    //if the username and password blank
    header('location:login.php?error=1');
    break;
} else if (empty($t_username)) {
    //only if the username is empty
    header('location:login.php?error=2');
    break;
} else if (empty($t_password)) {
    //only if the password is empty
    //redirect to pages index
    header('location:login.php?error=3');
    break;
}
 
$q = mysql_query("select * from teacher where t_username='$t_username' and t_password='$t_password'");
 
if (mysql_num_rows($q) == 1) {
    //kalau username dan password sudah terdaftar di database
	 $_SESSION['t_username'] = $t_username;
    header('location:home.php');
} else {
    //kalau username ataupun password tidak terdaftar di database
    header('location:login.php?error=4');
}

?>
