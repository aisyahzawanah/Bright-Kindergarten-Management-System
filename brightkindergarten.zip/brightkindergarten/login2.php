<?php
include('mysql_connect.php');
 
session_start();
 
//Accept data from login.php
$username = $_POST['username'];
$password = $_POST['password'];
 
//to prevent sql injection
//we use mysql_real_escape_string
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
 
//check the data sent, whether empty or not
if (empty($username) && empty($password)) {
    //if the username and password blank
    header('location:login.php?error=1');
    break;
} else if (empty($username)) {
    //only if the username is empty
    header('location:login.php?error=2');
    break;
} else if (empty($password)) {
    //only if the password is empty
    //redirect to pages index
    header('location:login.php?error=3');
    break;
}
 
$q = mysql_query("SELECT * FROM login WHERE username='$username' and password='$password'");
$row = mysql_fetch_array($q) or die(mysql_error());

if(mysql_num_rows($q) == 1)
{
	if ($row ['type'] == 'admin')
	{
		$_SESSION['username'] = $row['username'];
		header ('location:../brightkindergarten/admin/home.php');
	}
	else if ($row ['type'] == 'teacher')
	{
	$_SESSION['username'] = $row['username'];
	header ('location:../brightkindergarten/teachers/home.php');
	}
}
else
{
	header('location:login.php?error=4');
}

?>
