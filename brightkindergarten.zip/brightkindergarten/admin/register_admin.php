<?php
include('check_login.php');
include('mysql_connect.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">

    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href="../design/vendors/form-helpers/css/bootstrap-formhelpers.min.css" rel="stylesheet">
    <link href="../design/vendors/select/bootstrap-select.min.css" rel="stylesheet">
    <link href="../design/vendors/tags/css/bootstrap-tags.css" rel="stylesheet">

    <link href="../design/css/forms.css" rel="stylesheet">

  <script type="text/javascript" src="../design/js/jquery.min.js"></script>
  <script type="text/javascript" src="../design/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../design/js/scripts.js"></script>  
 
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Subject </a></li>
		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>			
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				<li><a href="student_information.php"> Print Students List </a></li>		                
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classroom</a></li>
			  	<li><a href="view_class.php"> List of Classrooms</a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Annoucement </a></li>

		</ul>
             </div>
	</div>
            
            
	<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title">REGISTER NEW ADMIN</div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		    <form class="form-horizontal" role="form" method="post">
		    
		    <fieldset>       
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Full Name</label>
			      <div class="col-md-10">
				<input class="form-control" id = "admin_name"  name="admin_name" type="text" />
			      </div>
			</div>

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">IC</label>
			      <div class="col-md-10">
				<input class="form-control" id = "IC"  name="IC" placeholder="example: 951229147705" type="text" />
			      </div>
			</div>	

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">E-mail</label>
			      <div class="col-md-10">
				<input class="form-control" id = "email"  name="email" type="email" />
			      </div>
			</div>	
								 
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Phone No.</label>
			      <div class="col-md-10">
				<input class="form-control" id = "phone_num"  name="phone_num" placeholder="example:0171234567" type="text" />
			      </div>
			</div>	
                
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Username</label>
			      <div class="col-md-10">
				<input class="form-control" id = "username"  name="username" type="text" />
			      </div>
			</div>	                

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Password</label>
			      <div class="col-md-10">
				<input class="form-control" id ="password"  name="password"  type="password" />
			      </div>
			</div>						
			
			<br/>
			<br/>
                
            <center>
            		<div class="form-group">
                	   <div class="col-lg-7">
                               <button class="btn btn-danger" type="reset" name="reset">Clear Fields</button> &nbsp; &nbsp;                       
                               <button class="btn btn-success" type="submit" name="register"> Register Admin </button>
                           </div>                
                       </div>
		       </center>
                
            <br/>    
   
<?php
	 
if (isset ($_POST['register'] )) 
{ //Check user pressed submit button or not
    
    require_once ('mysql_connect.php'); //Connect to the db
	 
    //validation signup
    if (!empty($_POST['admin_name']))
    {
	       $admin_name =$_POST['admin_name'];
    }
    else
    {
	       $admin_name = NULL;
	       echo '<p><center><b>You forgot to enter fullname!</b></center></p>';
    }

    if (!empty($_POST['IC']))
    {
	       $IC = $_POST['IC'];
    }
    else
    {
	       $IC = NULL;
	       echo '<p><center><b>You forgot to enter ic number!</b></center></p>';
    }
    
    if (!empty($_POST['email']))
    {
	       $email = $_POST['email'];
    }
    else
    {
	       $email = NULL;
	       echo '<p><center><b>You forgot to enter email!</b></center></p>';
    }   
	 
    if (!empty($_POST['phone_num']))
    {
	 		$phone_num = $_POST['phone_num'];
    }
    else
    {
            $phone_num = NULL;
	        echo '<p><center><b>You forgot to enter contact number!</b></center></p>';
    }
    
    if (!empty($_POST['username']))
    {
	 		$username = $_POST['username'];
    }
    else
    {
	        $username = NULL;
	        echo '<p><center><b>You forgot to enter username!</b></center></p>';
    }                         
	 	     	     
    if (!empty($_POST['password']))
    {
	        $password = $_POST['password'];
    }
    else
    {
	        $password = NULL;
	        echo '<p><center><b>You forgot to enter password!</b></center></p>';
    }    
	     
    if ($admin_name && $IC && $email && $phone_num && $username && $password) 
    {
	
             //make the query
             $query ="INSERT INTO admin (admin_name, IC, email,  phone_num, username, password) VALUES
	 		         ('$admin_name', '$IC', '$email', '$phone_num', '$username', '$password')";
	 		         $result= mysql_query ($query); //run the query.
	 		         if($result)
	 		         {//if it ran Ok.
	
	    			       $message='Thank you, new admin has been registered!';
	    			       echo "<SCRIPT>
	    			       alert('$message');
	    						 </SCRIPT>";
	    
	    					Print '<script>window.location.assign("profile.php");</script>'; //redirects to login form
	
	 		          }
	 		          else
				      {  //if it not ran
	
	   						echo'<h1 id="mainhead">system error</h1>
   	   						<p class="error">you could not register new admin due to system error.we apologize for any inconvience.</p>';
	  						//public message.
	 						echo'<p>'.mysql_error().'<br/>
	  						<br/>Query:'.$query.'</p>'; // debugging message.
				      }
     }
    else
    {
            echo'<p><center><font color="red">please go back and fill out the form again.</font></center></p>';
    }
}
?>					                
                
	    </div>
	</div>             
     </div>
   </div>
  </div>
</div>

<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten Management </div>
  </div>
</footer>


   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
</body>
</html>				