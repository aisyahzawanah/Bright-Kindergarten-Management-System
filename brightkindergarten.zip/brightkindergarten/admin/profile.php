<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">

    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Subject </a></li>
		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>			
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				<li><a href="student_information.php"> Print Students List </a></li>		                
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classroom</a></li>
			  	<li><a href="view_class.php"> List of Classrooms</a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Annoucement </a></li>

		</ul>
             </div>
	</div>
</head>
<body>

<div class="row">
  <div class="col-md-9">
    <div class="content-box-large">
        
         <?php
     if (!empty($_GET['message']) && $_GET['message'] == 'success') 
     {
     	echo '<div class="alert alert-success">' ;
     	echo '<h4><center>Success Adding Admin</center></h4>';
     	echo '</div>';
     }
     else if (!empty($_GET['message']) && $_GET['message'] == 'update')
     {
     	echo '<div class="alert alert-success">' ;
     	echo '<h4><center>Success Update Admin</center></h4>';
     	echo '</div>';
     }
     else if (!empty($_GET['message']) && $_GET['message'] == 'delete') 
     {
     	echo '<div class="alert alert-success">' ;
     	echo '<h4><center>Success Delete Admin</center></h4>';
     	echo '</div>';
     }
     ?>    
        
      <div class="panel-heading">
          <center><div class="panel-title"><strong> ADMIN PROFILE </strong></div></center>
      </div>

      <div class="row-fluid">
      <?php	
      $count_client=mysql_query("select * from admin");
      $count = mysql_num_rows($count_client);
      ?>	

      <!-- block -->						
      <div id="block_bg" class="block">	
	 <div class="navbar navbar-inner block-header">
	    <br/>
	    &nbsp;&nbsp;&nbsp;
	    <a button type='button' class="btn btn-primary" href="home.php">Back</a>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
       
        
        <a href="register_admin.php" button type='button' class="btn btn-info" href="home.php">Register New Admin</a>
	 </div>
			
	 <div class="panel-body">
	   <form method="post">
	     <table class="table">
	     	   					    
	      <div class="muted pull-right">&nbsp;Admin Available</div><div class="muted pull-right"><span class="label label-warning"><?php echo $count;?></span></div>
	      <script src="js/jquery.dataTables.min.js"></script>
	      <script src="js/DT_bootstrap.js"></script>
	      <br/><br/>
	     	   					
	       <thead>
 	       
	         <tr>
		     <th><center>Name</center></th>
	    	     <th><center>IC</center></th>
	    	     <th><center>Email</center></th>
	    	     <th><center>No. Phone</center></th>
		     <th><center>Username</center></th>	 
	    	     <th><center>Edit</center></th>
	    		<script src="../js/jquery.dataTables.min.js"></script>
	    		<script src="../js/DT_bootstrap.js"></script>
                <th><center>Delete</center></th>
	
		</tr>
	     </thead>
	   <tbody>   
	      
	   <?php
	   $user_query = mysql_query("select * from admin")or die(mysql_error());
	   while($row = mysql_fetch_array($user_query)){
	   $id = $row['id'];
	   ?>
	   
           <tr>
	     <td><center><?php echo $row['admin_name']; ?></center></td>
	     <td><center><?php echo $row['IC']; ?></center></td>
	     <td><center><?php echo $row['email']; ?></center></td>
	     <td><center><?php echo $row['phone_num']; ?></center></td>
	     <td><center><?php echo $row['username']; ?></center></td>
	     <td class="col-md-1">
             <center><a href="edit_admin.php <?php echo '?id='.$id; ?>" class="btn btn-success"><i class="glyphicon glyphicon-pencil"></i></a></center>
         </td>
         <td class ="col-md-1">
            <center><a href="delete_admin.php <?php echo '?id='.$id; ?>" class="btn btn-danger" onClick="return confirm('Are you sure to delete this data?')")><i class="glyphicon glyphicon-trash"></i></a> </center>
          </td>
	   </tr>
			     
	   <?php } ?>
	   </tbody>
          </table>
         </form>			 	   
	</div>
       </div>
      </div>
     </div>
    </div>
   </div>
  </div>
</div>
    
    
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>
    
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://code.jquery.com/jquery.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="../design/bootstrap/js/bootstrap.min.js"></script>
  <script src="../design/js/custom.js"></script>
</body>
</html>
