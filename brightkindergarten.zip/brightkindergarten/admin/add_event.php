<form id="signin_student" class="form-signin" method="post">	
 <h4 class="form-signin-heading"><i class="glyphicon glyphicon-plus"></i><strong> &nbsp; &nbsp; ADD EVENT </strong></h4>
 
 <br/><br/>
 
   <div class="form-group">
     <label class="col-md-4 control-label" for="text-field">Date Start</label>
       <div class="col-md-9">
         <input class="form-control" id = "date"  name="date_start" type="date" required autocomplete="off" />
	</div>
  </div>
  
  <br/><br/><br/><br/>
  
   <div class="form-group">
     <label class="col-md-4 control-label" for="text-field">Date End</label>
       <div class="col-md-9">
         <input class="form-control" id = "date"  name="date_end" type="date" required autocomplete="off" />
	</div>
  </div> 
  
  <br/><br/><br/><br/>  
  
   <div class="form-group">
     <label class="col-md-4 control-label" for="text-field">Title</label>
       <div class="col-md-9">
         <input class="form-control" id = "title"  name="title" type="text" required autocomplete="off" />
	</div>
  </div> 
  
 <br/><br/>
  
  <br/><br/>
  <div class="form-group">
   <div class="col-lg-3">
     <center><button class="btn btn-success" type="submit" name="add" value="true">Save</button></center>
   </div>                
  </div>	
</form>

<br/><br/><br/><br/>

<?php
if (isset($_POST['add']))
{
    $date_start = $_POST['date_start'];
    $date_end = $_POST['date_end'];
    $title = $_POST['title'];
				
    $event_query = mysql_query("insert into calendar_event (date_end,date_start,event_title) values('$date_end','$date_start','$title')")or die(mysql_error());
?>

<script>
window.location = "view_event.php";
</script>
			
<?php
}
?>
