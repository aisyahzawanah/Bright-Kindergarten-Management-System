<?php

//continue the session that was made before
session_start();
 
//delete the created session
session_destroy();
 
//redirect to login page
header('location:../login.php');

?>