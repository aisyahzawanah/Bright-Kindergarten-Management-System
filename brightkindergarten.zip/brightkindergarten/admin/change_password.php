<?php
include('check_login.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet"/>    

  </head>
  <body>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

     <div class="page-content">
     	<div class="row">
 		<div class="col-md-2">
 		  	<div class="sidebar content-box" style="display: block;">		  
                 <ul class="nav">
                     <!-- Main menu -->
                     <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
 		    <li class='submenu'>
 		       <a href='#'>
 			  <i class="glyphicon glyphicon-calendar"></i> Calendar
 			  <span class="caret pull-right"></span>
 		       </a>
 		       <ul>
 		    	 <li><a href="calendar_event.php"> Add Event </a></li>
 		    	 <li><a href="view_event.php"> List of Events </a></li>
 		      </ul>
 		    </li>	
 		    	<li class='submenu'>
 			    <a href='#'> 
 			       <i class="glyphicon glyphicon-cog"></i> Profile
 			       <span class="caret pull-right"></span>
 			   </a>
 		    	   <ul>
 		    	       <li><a href="profile.php"> My Profile </a></li>
 		    	       <li><a href="change_password.php"> Change Password </a></li>
 		    	   </ul>
 		    	</li>
 		    	<li class='submenu'>
 			    <a href='#'>
 			       <i class="glyphicon glyphicon-pencil"></i> Academic
 			       <span class="caret pull-right"></span>
 			    </a>
 		    	    <ul>
 		    	      <li><a href="add_subject.php"> Add Subject </a></li>
 		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
 		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>			   
 		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
 		    	   </ul>
 		     	</li>			     
 		         <li class='submenu'> 
 			     <a href='#'>
 			       <i class="glyphicon glyphicon-list"></i> Student
 			       <span class="caret pull-right"></span>
 			     </a>
 		             <ul>
 		                <li><a href="student_registration.php"> Register Student </a></li>
 		                <li><a href="student_class.php"> List of Students </a></li>
 				<li><a href="student_information.php"> Print Students List </a></li>		                
 		            </ul>
 		         </li>
 		          <li class='submenu'>
 			     <a href='#'>
 			        <i class="glyphicon glyphicon-user"></i> Teacher
 				<span class="caret pull-right"></span>
 			     </a>
 		             <ul>
 		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
 		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
 		             </ul>
 		          </li> 
 			  <li class='submenu'> 
 			     <a href='#'>
 			        <i class="glyphicon glyphicon-link"></i> Class
 			  	<span class="caret pull-right"></span>
 			     </a>
 			    <ul>
 			  	<li><a href="add_class.php"> Add Classroom </a></li>
 			  	<li><a href="view_class.php"> List of Classrooms </a></li>
 			    </ul>
 			  </li>				  			  
 			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
 		</ul>
              </div>
 	</div>
	
	<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title"> CHANGE PASSWORD </div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		 
		<?php

   		$page_title = 'Change Admin Password';
   
   		//Check for form submission
   		if(isset($_POST['submitted']))
   		{
        		require_once('connect.php'); //connect to the database
	
			function escape_data($data)
			{
				global $dbc;
				if(ini_get('magic_quotes_gpc'))
				{
					$data = stripslashes($data);
				}
					return mysql_real_escape_string(trim($data), $dbc);
			}
	
			$errors= array ();
	
			//Check for an email address
			if(empty($_POST['email']))
			{
	    			$errors[] = 'You forgot to enter your email ';
			}
			else
			{
	    			$e = escape_data($_POST['email']);
			}
	
			//Check for the current password
			if(empty($_POST['password']))
			{
	    			$errors[] = 'You forgot to enter your current password';
			}
			else
			{
	    			$p = escape_data($_POST['password']);
			}
	
			//Check for a new password and match
			if(!empty($_POST['Admin_Password1']))
			{
	    			if($_POST['Admin_Password1'] != $_POST['Admin_Password2'])
	    			{
	       				$errors[] = 'Your new password did not match the confirmed password.';
	    			}
	    			else
	    			{
	       				$np = escape_data($_POST['Admin_Password1']);
	    			}
			}
			else
			{
	    			$errors[] = 'You forgot to enter your new password.';
			}
	
			if(empty($errors)) //If everything's OK
			{
	    			//Check that they've entered the right email address/password combination
	    			$query = "SELECT id FROM admin WHERE (email='$e' AND password='$p')";
	    			$result = mysql_query($query);
	    			$num = mysql_num_rows($result);
	    
	    			if(mysql_num_rows($result) == 1 ) //Match was made
	    			{
	        			//Get the cust_id
					$row = mysql_fetch_array($result, MYSQL_NUM);
		
					//Make the UPDATE query
					$query = "UPDATE admin SET password='$np' WHERE id = $row[0]";
					$result = @mysql_query($query);
		
					if(mysql_affected_rows() == 1) //If it ran OK
					{
		   				//Print a message
		   				echo '<h1>Thank You</h1>
			  			     <p>Your password has been updated. </p><p><br/></p>';
		  				exit();  
					}
					else //If it did not run OK
					{
		   				//Public message
		   				echo '<h1>System Error</h1>
		        			<p class = "error"> Your password could not be changed due to a system error. We apologize for any inconvenience.</p>';
			
		  		 		//Debugging message
		   				echo '<p>' . mysql_error() . '<br/><br/>Query: ' . $query . '</p>';
		   				exit();
	    				}
	    			}
	    			else //Invalid email address/password combination
	    			{
	        			echo '<h1>Error!</h1>
		      			<p class = "error"> The email address and password do not match those on file. </p>';
	    			}
	 		} 
		{
	    		echo '<h1>Error!</h1>
		  	<p class = "error"> The following error(s) occurred:<br/>';
			  
	    		foreach($errors as $msg) //Print each error
	    		{
		  		echo " - $msg <br/>\n";
	    		}
		
	     			echo '</p><p>Please try again</p><p><br/></p>';
		} //End of if (empty($errors)) IF
	    
	    		mysql_close(); //Close database connection
        	}

?>		 		 	 		 	 
		 
		    <form class="form-horizontal" method="post" action="change_password.php">
		    <fieldset>		    						    
					    
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">E-mail</label>
			      <div class="col-md-10">
				<input class="form-control" id = "email"  name="email" type="text" placeholder="Email" required autocomplete="off" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" />
			      </div>
			</div>					    					
									
			<div class="form-group">
			    <label class="col-md-2 control-label" for="text-field"> Current Password </label>
				<div class="col-md-10">
				    <input class="form-control" id ="password"  name="password" type="password" placeholder="Current Password" required autocomplete="off" />
				</div>
			</div>
			
			<div class="form-group">
			    <label class="col-md-2 control-label" for="text-field"> New Password </label>
				<div class="col-md-10">
				    <input class="form-control" id ="password"  name="Admin_Password1" type="password" placeholder="New Password" required autocomplete="off" />
				</div>
			</div>	
			
			<div class="form-group">
			    <label class="col-md-2 control-label" for="text-field"> Confirmation Password </label>
				<div class="col-md-10">
				    <input class="form-control" id ="password"  name="Admin_Password2" type="password" placeholder="Confirm Password" required autocomplete="off" />
				</div>
			</div>												    						    
				    
           		<div class="form-group">
                           <div class="col-lg-6">
                               <center><button class="btn btn-success" type="hidden" name="submitted" value="true">Change Password</button></center>
                           </div>                
                       </div>
		       </fieldset>
		    </form>
	       </div>
	   </div>
       </div>
    </div>
   </div>
</div>

<?php include('script.php'); ?>    


<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>


   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
</body>
</html>	
		    
		   		    	