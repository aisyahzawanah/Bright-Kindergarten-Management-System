<link href="../design/css/styles.css" rel="stylesheet" media="screen">      
	
<!--------------------------------------/.fluid-container-------------------------------------->
<link href="../design/css/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen"> 
<script src="../design/css/easypiechart/jquery.easy-pie-chart.js"></script>
<script src="../design/js/scripts.js"></script>

<script>
$(function() 
{
	<!-----------------------Easy pie charts---------------------------------->
	$('.chart').easyPieChart({animate: 1000});
});
</script>
				
<!------------------------------------- jgrowl-------------------------------------------- -->
<script src="../design/css/jGrowl/jquery.jgrowl.js"></script>   
<script>
$(function() 
{
      $('.tooltip').tooltip();	
      $('.tooltip-left').tooltip({ placement: 'left' });	
      $('.tooltip-right').tooltip({ placement: 'right' });	
      $('.tooltip-top').tooltip({ placement: 'top' });	
      $('.tooltip-bottom').tooltip({ placement: 'bottom' });
      $('.popover-left').popover({placement: 'left', trigger: 'hover'});
      $('.popover-right').popover({placement: 'right', trigger: 'hover'});
      $('.popover-top').popover({placement: 'top', trigger: 'hover'});
      $('.popover-bottom').popover({placement: 'bottom', trigger: 'hover'});
      $('.notification').click(function() 
      {
	    var $id = $(this).attr('id');
	    switch($id) 
	    {
		
		    case 'notification-sticky':
		    $.jGrowl("Stick this!", { sticky: true });
		    break;
		    case 'notification-header':
		    $.jGrowl("A message with a header", { header: 'Important' });
		    break;
		    default:
		    $.jGrowl("Hello world!");
		    break;
	    }
       });
});
</script>

<link href="../design/css/datepicker.css" rel="stylesheet" media="screen">
<link href="../design/css/uniform.default.css" rel="stylesheet" media="screen">
<link href="../design/css/chosen.min.css" rel="stylesheet" media="screen">

<!--  -->
<script src="../design/js/jquery.uniform.min.js"></script>
<script src="../design/js/chosen.jquery.min.js"></script>
<script src="../design/js/bootstrap-datepicker.js"></script>

<!--  -->
<script src="../design/js/wysihtml5-0.3.0.js"></script>
<script src="../design/js/bootstrap-wysihtml5.js"></script>
<script src="../design/js/ckeditor/ckeditor.js"></script>
<script src="j../design/s/ckeditor/adapters/jquery.js"></script>
<script type="text/javascript" src="../design/js/tinymce/js/tinymce/tinymce.min.js"></script>

<script>
$(function() 
{
           <!-------------------------------Ckeditor standard-------------------------------------->
            $( 'textarea#ckeditor_standard' ).ckeditor({width:'98%', height: '150px', toolbar: [
				{ name: 'document', items: [ 'Source', '-', 'NewPage', 'Preview', '-', 'Templates' ] },	// Defines toolbar group with name (used to create voice label) and items in 3 subgroups.
				[ 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo' ],			// Defines toolbar group without name.
				{ name: 'basicstyles', items: [ 'Bold', 'Italic' ] }
			]});
            $( 'textarea#ckeditor_full' ).ckeditor({width:'98%', height: '150px'});
});
</script>
		
<!-- ----------<script type="text/javascript" src="admin/assets/modernizr.custom.86080.js"></script> ------------------------->
<script src="../design/js/jquery.hoverdir.js"></script>
<link rel="stylesheet" type="text/css" href="../design/css/style.css" />

<script type="text/javascript">
$(function() 
{
	$('#da-thumbs > li').hoverdir();
});
</script>

<script src="../design/js/fullcalendar/fullcalendar.js"></script>
<script src="../design/js/fullcalendar/gcal.js"></script>
<link href="../design/js/datepicker.css" rel="stylesheet" media="screen">
<script src="../design/js/bootstrap-datepicker.js"></script>

<script>
$(function() 
{
      $(".datepicker").datepicker();
      $(".uniform_on").uniform();
      $(".chzn-select").chosen();
      $('#rootwizard .finish').click(function() 
      {
		alert('Finished!, Starting over!');
		$('#rootwizard').find("a[href*='tab1']").trigger('click');
      });
});
</script>