<?php

include('mysql_connect.php');
include('check_login.php');

$admin_id = $_GET['id'];
 
$query = mysql_query("delete from admin where id='$admin_id'") or die(mysql_error());
 
if ($query) 
{
    header('location:profile.php?message=delete');
}
?>