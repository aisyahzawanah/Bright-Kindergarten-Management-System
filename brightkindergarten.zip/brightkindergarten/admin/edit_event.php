<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../design/vendors/fullcalendar/fullcalendar.css" rel="stylesheet" media="screen">
    <!-- styles -->
     <link href="../design/css/styles.css" rel="stylesheet" />
    <link href="../design/css/calendar.css" rel="stylesheet"/>     
   </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

     <div class="page-content">
     	<div class="row">
 		<div class="col-md-2">
 		  	<div class="sidebar content-box" style="display: block;">		  
                 <ul class="nav">
                     <!-- Main menu -->
                     <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
 		    <li class='submenu'>
 		       <a href='#'>
 			  <i class="glyphicon glyphicon-calendar"></i> Calendar
 			  <span class="caret pull-right"></span>
 		       </a>
 		       <ul>
 		    	 <li><a href="calendar_event.php"> Add Event </a></li>
 		    	 <li><a href="view_event.php"> List of Events </a></li>
 		      </ul>
 		    </li>	
 		    	<li class='submenu'>
 			    <a href='#'> 
 			       <i class="glyphicon glyphicon-cog"></i> Profile
 			       <span class="caret pull-right"></span>
 			   </a>
 		    	   <ul>
 		    	       <li><a href="profile.php"> My Profile </a></li>
 		    	       <li><a href="change_password.php"> Change Password </a></li>
 		    	   </ul>
 		    	</li>
 		    	<li class='submenu'>
 			    <a href='#'>
 			       <i class="glyphicon glyphicon-pencil"></i> Academic
 			       <span class="caret pull-right"></span>
 			    </a>
 		    	    <ul>
 		    	      <li><a href="add_subject.php"> Add Subject </a></li>
 		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
 		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>		
 		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
 		    	   </ul>
 		     	</li>			     
 		         <li class='submenu'> 
 			     <a href='#'>
 			       <i class="glyphicon glyphicon-list"></i> Student
 			       <span class="caret pull-right"></span>
 			     </a>
 		             <ul>
 		                <li><a href="student_registration.php"> Register Student </a></li>
 		                <li><a href="student_class.php"> List of Students </a></li>
 				<li><a href="student_information.php"> Print Students List </a></li>		                
 		            </ul>
 		         </li>
 		          <li class='submenu'>
 			     <a href='#'>
 			        <i class="glyphicon glyphicon-user"></i> Teacher
 				<span class="caret pull-right"></span>
 			     </a>
 		             <ul>
 		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
 		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
 		             </ul>
 		          </li> 
 			  <li class='submenu'> 
 			     <a href='#'>
 			        <i class="glyphicon glyphicon-link"></i> Class
 			  	<span class="caret pull-right"></span>
 			     </a>
 			    <ul>
 			  	<li><a href="add_class.php"> Add Classroom </a></li>
 			  	<li><a href="view_class.php"> List of Classrooms </a></li>
 			    </ul>
 			  </li>				  			  
 			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
 		</ul>
              </div>
 	</div>

	<div class="col-md-10">
	  <div class="content-box-large">
	    <div class="panel-body">
	      <div class="row">

		<div class="col-md-7">
		  <div id='calendar'></div>
		</div>
		
		<div class="col-md-5">
		  <form id="signin_student" class="form-signin" method="post">	
 		     <h4 class="form-signin-heading"><i class="glyphicon glyphicon-plus"></i><strong> &nbsp; &nbsp; EDIT EVENT </strong></h4>
 
                     <br/><br/>
		     
		     <?php
             $id = $_GET['id'];
	         $select = "SELECT * FROM calendar_event WHERE event_id= $id";
			 
		     $result = mysql_fetch_array(mysql_query($select));
	         $qry=mysql_query($select);
		   
		     if($qry)
		     {
		        while($rec = mysql_fetch_array($qry))
		        {
		           $event_title = "$rec[event_title]";
		           $date_start = "$rec[date_start]";
			       $date_end = "$rec[date_end]";		
		        }
		    }

	        if (isset($_POST['update']))
		    {
		        if (($_POST['event_title'] == '')or($_POST['date_start'] == '')or($_POST['date_end'] == ''))
			{
			   echo "You Must Fill All";
			}
	                else
			{
		       $event_title = addslashes("$_POST[event_title]");
			   $date_start = addslashes("$_POST[date_start]");
			   $date_end = addslashes("$_POST[date_end]");

			  mysql_query("UPDATE calendar_event SET event_title ='$event_title', date_start ='$date_start', 
			  date_end ='$date_end' WHERE event_id = '$id'")or die(mysql_error()); 
			
                       }
                   ?>
		  
                  <script>
		  alert('Updated Successfully');
		  window.location = "view_event.php";
		  </script>
              
		  <?php
		  }?> 
		  
                  <div class="form-group">
     		    <label class="col-md-4 control-label" for="text-field">Date Start</label>
       		      <div class="col-md-9">
         		<input class="form-control" id = "date"  name="date_start" type="date" value="<?php echo $date_start;?>"  />
		      </div>
  		</div>
  
  		<br/><br/><br/><br/>
  
   		<div class="form-group">
     		  <label class="col-md-4 control-label" for="text-field">Date End</label>
       		    <div class="col-md-9">
         	      <input class="form-control" id = "date"  name="date_end" type="date" value="<?php echo $date_end;?>" />
		    </div>
  	       </div> 
  
  		<br/><br/><br/><br/>  
  
   		<div class="form-group">
     		  <label class="col-md-4 control-label" for="text-field">Title</label>
       		    <div class="col-md-9">
         	      <input class="form-control" id = "title"  name="event_title" type="text" value="<?php echo $event_title;?>" />
		    </div>
  	       </div> 
  
 	      <br/><br/><br/><br/>
		 
  	      <div class="form-group">
   	        <div class="col-lg-7">
		   <button type="submit" name="update" class="btn btn-info"><i class="glyphicon glyphicon-refresh"></i> Update</button>
		    <a button id="cancel" name="cancel" class="btn btn-danger" href="view_event.php" >Cancel</button></a>	
                </div>                
             </div>	
          </form>
	</div>	
      </div>
     </div>
    </div>
   </div>
  </div>
</div>

   <?php include('script.php'); ?>


<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy;  2018 Bright Kindergarten </div>
  </div>
</footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>

    <script src="../design/vendors/fullcalendar/fullcalendar.js"></script>
   
    <script src="../design/js/custom.js"></script>
    <script src="../design/js/calendar.js"></script>
        
        <script>
        $(function() 
        {
              $(".datepicker").datepicker();
              $(".uniform_on").uniform();
              $(".chzn-select").chosen();
              $('#rootwizard .finish').click(function() 
              {
        		alert('Finished!, Starting over!');
        		$('#rootwizard').find("a[href*='tab1']").trigger('click');
              });
        });
        </script>

  </body>
</html>			