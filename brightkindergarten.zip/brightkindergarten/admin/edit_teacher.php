<?php
include('check_login.php');
include('mysql_connect.php');
?>
<?php
$id = $_GET['id'];
$select = "SELECT * FROM teacher as t, class as c WHERE t.t_id = $id AND c.class_id = t.class_id";
$result = mysql_fetch_array(mysql_query($select));
$query=mysql_query($select);
if($query)
{
    while($rec = mysql_fetch_array($query))
    {
       $t_name = "$rec[t_name]";
       $NRIC = "$rec[NRIC]";
       $t_section = "$rec[t_section]";
       $t_email = "$rec[t_email]";
       $t_phone = "$rec[t_phone]";
       $t_username = "$rec[t_username]";		
    }
}
		
if (isset($_POST['update']))
{
    if (($_POST['class_id'] == '')or($_POST['t_name'] == '')or($_POST['NRIC'] == '')or($_POST['t_section'] == '')or($_POST['t_email'] == '')or($_POST['t_phone'] == '')or($_POST['t_username'] == ''))
    {
	echo "Must Fill All";
    }
    else
    {
	$c = addslashes("$_POST[class_id]");
	$n = addslashes("$_POST[t_name]");
	$i = addslashes("$_POST[NRIC]");
	$s = addslashes("$_POST[t_section]");
	$e = addslashes("$_POST[t_email]");
	$p = addslashes("$_POST[t_phone]");
	$u = addslashes("$_POST[t_username]");
	
	mysql_query("UPDATE teacher SET class_id ='$c', t_name ='$n', NRIC ='$i', t_section ='$s', t_email = '$e', 
	t_phone ='$p', t_username='$u' WHERE t_id = '$id'")or die(mysql_error()); 
     }
?>

<?php
$id = $_GET['id'];
$user_query = mysql_query("select * from teacher, class where teacher.class_id=class.class_id AND teacher.t_id=$id")or die(mysql_error());
while($row = mysql_fetch_array($user_query))
{
   $id1 = $row['class_id'];
}
?>

<script>
alert('Updated Successfully');
window.location = "view_teachers.php?id=<?php echo $id1;?>";
</script>
<?php
}?>

<!DOCTYPE html>
<html>
  <head>
    <title>e-kiims</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen" />

    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet" />

    <link href="../design///netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet" />
    <link href="../design/vendors/form-helpers/css/bootstrap-formhelpers.min.css" rel="stylesheet" />
    <link href="../design/vendors/select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="../design/vendors/tags/css/bootstrap-tags.css" rel="stylesheet" />

    <link href="../design/css/forms.css" rel="stylesheet" />

  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Subject </a></li>
		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				<li><a href="student_information.php"> Print Students List </a></li>		                
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teacher</a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classrooom </a></li>
			  	<li><a href="view_class.php"> List of Classroooms </a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
		</ul>
             </div>
	</div>
	    
<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title">EDIT TEACHER DETAILS</div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		    <form class="form-horizontal" method="post">
		               
		    <fieldset>
		    
		       <div class="form-group">
		       </div>
			    
		       <div class="form-group">
		       	   <label class="col-md-2 control-label" for="text-field">Class</label>
		       		<div class="col-md-10">
		       		<div class="bfh-selectbox" data-name="selectbox3" data-value="12" data-filter="true">
		       		<div data-value="1">
				   <select id="class_id" name="class_id" class="form-control" value="<?php echo $class_name?>" />  
					<option></option>
					<?php 
					$query=mysql_query("select * from class");
					while($row=mysql_fetch_array($query))
					{ 
					    if($result['class_id'] == $row['class_id'])
					    {
						 $sel = "selected";
					    }
					    else
					    {
						 $sel = "";
					    }
					?>
					<option value="<?php echo $row['class_id'];?>" <?=$sel?> > <?php echo $row['class_name'];?> </option>
					<?php 
					} 
					?>
				    </select>
		       		</div>				
		       		</div>
			      </div>
			</div>
				       
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Full Name</label>
			      <div class="col-md-10">
				<input class="form-control" name="t_name" id = "stud_name"  type="text" value="<?php echo $t_name?>" />
			      </div>
			</div>

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">IC</label>
			      <div class="col-md-10">
				<input class="form-control" id = "NRIC"  name="NRIC" type="text" value="<?php echo $NRIC?>" />
			      </div>
			</div>				
			 
			<div class="form-group">
			   <label class="col-md-2 control-label" >Session</label>
			      <div class="col-md-10">
				<label class="radio radio-inline">
				   <input type="radio" name="t_section" value="Morning" /> Morning
				</label>
				<label class="radio radio-inline">
				   <input type="radio" name="t_section" value="Evening" /> Evening
				</label>
			       </div>
			       <input type="hidden" name="t_section" id="t_section" value="<?php echo $t_section?>" />
			 </div>
	

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Email</label>
			      <div class="col-md-10">
				<input class="form-control" id = "t_email"  name="t_email" type="text" value="<?php echo $t_email?>" />
			      </div>
			</div>	
								 
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Phone No.</label>
			      <div class="col-md-10">
				<input class="form-control" id = "t_phone"  name="t_phone" type="text" value="<?php echo $t_phone?>" />
			      </div>
			</div>	
			
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Username</label>
			      <div class="col-md-10">
				<input class="form-control" id="username"  name="t_username" type="text" value="<?php echo $t_username?>" />
			      </div>
			</div>					
			
			<br/>

			<center>
            		<div class="form-group">
                	   <div class="col-lg-7">
                               <button class="btn btn-info" type="submit" id="submit" name="update" value="true"><i class="glyphicon glyphicon-refresh"></i> Update Teacher Details </button>
			       <a button name="cancel" class="btn btn-danger" href="class_teacher.php">Cancel</a></button>
                           </div>                
                       </div>
		       </center>
		</fieldset>
	    </div>
	</div>
     </div>
   </div>
  </div>
</div>

<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>

   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
    
    
</div>
</div>
</body>
</html>