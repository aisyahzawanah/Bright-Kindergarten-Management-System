<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Suject </a></li>
		    	      <li><a href="view_subject.php"> List of Sujects </a></li>
                        <li><a href="upload_timetable.php"> Upload Timetable </a></li>
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				<li><a href="student_information.php"> Print Students List </a></li>		                
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classroom </a></li>
			  	<li><a href="view_class.php"> List of Classroom </a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
		</ul>
             </div>
	</div>
	
	<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title">ADD ANNOUNCEMENT</div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		    <form class="form-horizontal" role="form" method="post">
		    
		    <fieldset>
			
			<div class="form-group">
			   <b><label class="col-md-2 control-label" for="text-field">Title</b></label>
			         <div class="col-md-10">
				     <input class="form-control" id = "title"  name="title" type="text" required/>
				  </div>
			</div>
			
			<div class="form-group">
			   <label class="col-md-2 control-label" for="textarea">Message</label>
			      <div class="col-md-10">
				<textarea class="form-control" id = "message"  name="message" rows="4" required /></textarea>
			      </div>
			</div>	
					
			 <div class="form-group">
			    <label class="col-md-2 control-label">Date Post</label>
			        <div class="col-md-10">
				   <input type="date" name="post_date" id ="post_date"  class="form-control" placeholder="2015-12-01" required />
				</div>	
			 </div>	

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Post By</label>
			      <div class="col-md-10">
				<input class="form-control" id = "post_by"  name="post_by" placeholder="Fatimah" type="text" required />
			      </div>
			</div>
			
			<br/>
			<br/>
				

            <div class="form-group">
		<div class="col-lg-3" align="right">
                    <button class="btn btn-danger" type="reset" name="reset">Clear Fields</button>
                </div>
                <div class="col-lg-2" align="right">
                    <button class="btn btn-success" type="submit" name="register">Add Announcement</button>
                </div>                
            </div>
	    </div>
	</div>
    </div>
   </div>
   
 <?php
	if (isset($_POST['register']))
	{
	$post_by=$_POST['post_by'];
	$title=$_POST['title'];
	$message=$_POST['message'];
	$post_date=$_POST['post_date'];
	
	mysql_query("insert into announcement (ann_id, post_by, title, message, post_date) values 
	('','$post_by','$title','$message','$post_date')")or die(mysql_error());
?>

<?php 
$query=mysql_query("SELECT * FROM announcement")or die(mysql_error());
while($rec=mysql_fetch_array($query))
{
$ann_id = $rec['ann_id'];
}
?>

<script>
alert('Succsessfully Save');
window.location = "home.php?id=<?php echo $ann_id;?>";
</script>
<?php
}?>
   
	</div>
	</div>
 
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
  </body>
</html>