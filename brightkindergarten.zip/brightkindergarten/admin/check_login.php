<?php
session_start();
 
//if the session username is not made??, or empty username session
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    //redirect to login page
    header('location:login.php');
}
?>