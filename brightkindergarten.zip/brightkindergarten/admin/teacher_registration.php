<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet"/>

  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Subject </a></li>
		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				        <li><a href="student_information.php"> Print Students List </a></li>  
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classroom </a></li>
			  	<li><a href="view_class.php"> List of Classrooms </a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
		</ul>
             </div>
	</div>
	
	<div class="row">
	  <div class="col-md-9">
	    <div class="content-box-large">
	       <div class="panel-heading">
		  <center><b><div class="panel-title">REGISTER TEACHER</div></b></center>
	       </div>
	       <br/>
	       <br/>
		 <div class="panel-body">
		    <form class="form-horizontal" role="form" method="post">
		    
		    <fieldset>
		       <div class="form-group">
		       	   <label class="col-md-2 control-label" for="text-field">Class</label>
		       		<div class="col-md-10">
		       		<div class="bfh-selectbox" data-name="selectbox3" data-value="12" data-filter="true">
		       		<div data-value="1">
		       		   <select id="class_id" name="class_id" class="form-control" required>
		       		   	<option></option>
		       		   	<?php 
		       		   	$query=mysql_query("select * from class");
		       		   	while($row=mysql_fetch_array($query))
		       		   	{ ?>
		       		   	<option value="<?php echo $row['class_id'];?>"> <?php echo $row['class_name'];?> </option>
		       		   	<?php } ?>
		       		   </select>	
		       		</div>				
		       		</div>
			      </div>
			</div>
				       
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Full Name</label>
			      <div class="col-md-10">
				<input class="form-control" id = "t_name"  name="t_name" type="text" required/>
			      </div>
			</div>

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">IC Number</label>
			      <div class="col-md-10">
				<input class="form-control" id = "NRIC"  name="NRIC" placeholder="example: 950717142701" type="text" required />
			      </div>
			</div>			
			
			<div class="form-group">
			   <label class="col-md-2 control-label" required/>Sesi</label>
			      <div class="col-md-10">
				<label class="radio radio-inline">
				   <input type="radio" name="t_section" value="Morning" /> Morning
				</label>
				<label class="radio radio-inline">
				   <input type="radio" name="t_section" value="Evening" /> Evening
				</label>
			       </div>
			 </div>
	

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Email</label>
			      <div class="col-md-10">
				<input class="form-control" id = "t_email"  name="t_email" type="email" placeholder="example: rozma@gmail.com" required/>
			      </div>
			</div>	
								 
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Phone No.</label>
			      <div class="col-md-10">
				<input class="form-control" id = "t_phone"  name="t_phone" placeholder="example: 0171234567" type="text" required />
			      </div>
			</div>												  

			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Username</label>
			      <div class="col-md-10">
				<input class="form-control" id = "username"  name="t_username" placeholder="example: username" type="text" required />
			      </div>
			</div>			
			
			<div class="form-group">
			   <label class="col-md-2 control-label" for="text-field">Password</label>
			      <div class="col-md-10">
				<input class="form-control" id = "password"  name="password"  type="password" required />
			      </div>
			</div>				

			<br/>
			<br/>
				
            <div class="form-group">
                <div class="col-lg-5">
                    <button class="btn btn-danger" type="reset" name="reset">Clear Fields</button> &nbsp; &nbsp;
                    <button class="btn btn-success" type="submit" name="register"> Daftar Cikgu</button>
                </div>               
            </div>
	    </div>
	</div>
     </div>
   </div>
  </div>
</div>


<?php
	if (isset($_POST['register']))
	{
	$class_id=$_POST['class_id'];
	$t_name=$_POST['t_name'];
	$NRIC=$_POST['NRIC'];
	$t_section=$_POST['t_section'];
	$t_email=$_POST['t_email'];
	$t_phone=$_POST['t_phone'];
	$t_username=$_POST['t_username'];
	$t_password = $_POST['password'];
	
	mysql_query("insert into teacher (t_id, class_id, t_name, NRIC, t_section, t_email, t_phone, username, password) values 
	('','$class_id','$t_name','$NRIC','$t_section','$t_email','$t_phone', '$t_username', '$t_password')")or die(mysql_error());
	
	mysql_query("insert into login (id, username, password, type) values ('', '$t_username', '$t_password', 'teacher')") or die (mysql_error());
?>

<?php 
$query=mysql_query("SELECT * FROM teacher")or die(mysql_error());
while($rec=mysql_fetch_array($query))
{
$id = $rec['class_id'];
}?>

<script>
alert('Succsessfully Save');
window.location = "view_teachers.php?id=<?php echo $id;?>";
</script>
<?php
}?>

<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>


   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
</body>
</html>				