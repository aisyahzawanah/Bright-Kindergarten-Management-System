<?php
include('mysql_connect.php');
include('check_login.php');
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">
    
    <link href="../design/css/print.css" rel="stylesheet" type="text/css" media="print">

  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Subject </a></li>
		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>		
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				<li><a href="student_information.php"> Print Students List </a></li>		                
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classroom </a></li>
			  	<li><a href="view_class.php"> List of Classrooms </a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
		</ul>
             </div>
	</div>
	    	    
	<div class="row">
	   <div class="col-md-9">
	      <div class="content-box-large">
		 <div class="panel-heading">
		    	<center><b><div class="panel-title">LIST OF STUDENTS IN SCHOOL</div></b></center>
		 </div>
  		 <div class="panel-body">
		   
		   <br/><br/>
		   
  	           <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
		     <thead>
		       <tr>
			 <th>Class</th>
			 <th>Name</th>
			 <th>Gender</th>
			 <th>Date of Birth</th>
			 <th>Birth Certificate No.</th>
             <th>Address</th>
			 <th>Guardian Name</th>
			 <th>Guardian Phone No.</th>
			 <th>Guardian Occupation</th>
			 			 
		      </tr>
		     </thead>
		  
				  
	                    <?php 
			    $query=mysql_query("select * FROM student, class where student.class_id=class.class_id AND class.class_id=class.class_id")or die(mysql_error());
			    while($rec=mysql_fetch_array($query)){
			    ?>
			    <tr class="edit_tr">
			    <td><?php echo $rec['class_name']; ?></td>
			    <td><?php echo $rec['stud_name']; ?></td>
			    <td><?php echo $rec['stud_gender'] ?></td>
			    <td><?php echo $rec['DOB'] ?></td>
			    <td><?php echo $rec['BCN'] ?></td>
                <td><?php echo $rec['stud_address'] ?></td>
			    <td><?php echo $rec['guardian_name'] ?></td>
			    <td><?php echo $rec['guardian_phone_num'] ?></td>
			    <td><?php echo $rec['guardian_occupation'] ?></td>  
			    </tr><?php }?>
		      </table>
		  </div>
   	  
	    <div class="empty">
		 <a id="print" onclick="window.print()"  class="btn btn-primary"><i class="glyphicon glyphicon-print"></i> Print Log </a></button>
	   </div>		  
	   	 
	      </div>
	     </div>
	</div>	     
    </div>
</div>
				  
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>

    <link href="../design/vendors/datatables/dataTables.bootstrap.css" rel="stylesheet" media="screen"/>
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    
    <script src="../design/vendors/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../design/vendors/datatables/dataTables.bootstrap.js"></script>
    <script src="../design/js/custom.js"></script>
    <script src="../design/js/tables.js"></script>
    
  </body>
</html>