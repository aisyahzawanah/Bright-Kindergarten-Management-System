<?php
include('check_login.php');
include('mysql_connect.php'); //Connect to the db
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bright Kindergarten Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">            

    <!-- Bootstrap -->
    <link href="../design/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="../design/css/styles.css" rel="stylesheet">

    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href="../design/vendors/form-helpers/css/bootstrap-formhelpers.min.css" rel="stylesheet">
    <link href="../design/vendors/select/bootstrap-select.min.css" rel="stylesheet">
    <link href="../design/vendors/tags/css/bootstrap-tags.css" rel="stylesheet">

    <link href="css/forms.css" rel="stylesheet">
    
    <script type="text/javascript" src="../design/js/jquery.min.js"></script>
    <script type="text/javascript" src="../design/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../design/js/scripts.js"></script>

  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="home.php">Admin</a></h1>
	              </div>
	           </div>
		   
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <?php echo $_SESSION['username'] ?> <i class="caret"></i>
				</a>
                                <ul class="dropdown-menu">                               
                                    <li>
                                        <a tabindex="-1" href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
		    		  
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">		  
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="home.php"><i class="glyphicon glyphicon-home"></i> Homepage </a></li>
		    <li class='submenu'>
		       <a href='#'>
			  <i class="glyphicon glyphicon-calendar"></i> Calendar
			  <span class="caret pull-right"></span>
		       </a>
		       <ul>
		    	 <li><a href="calendar_event.php"> Add Event </a></li>
		    	 <li><a href="view_event.php"> List of Events </a></li>
		      </ul>
		    </li>	
		    	<li class='submenu'>
			    <a href='#'> 
			       <i class="glyphicon glyphicon-cog"></i> Profile
			       <span class="caret pull-right"></span>
			   </a>
		    	   <ul>
		    	       <li><a href="profile.php"> My Profile </a></li>
		    	       <li><a href="change_password.php"> Change Password </a></li>
		    	   </ul>
		    	</li>
		    	<li class='submenu'>
			    <a href='#'>
			       <i class="glyphicon glyphicon-pencil"></i> Academic
			       <span class="caret pull-right"></span>
			    </a>
		    	    <ul>
		    	      <li><a href="add_subject.php"> Add Subject </a></li>
		    	      <li><a href="view_subject.php"> List of Subjects </a></li>
		    	      <li><a href="upload_timetable.php"> Upload Timetable </a></li>			
		    	      <li><a href="view_timetable.php"> List of Timetable </a></li>				  
		    	   </ul>
		     	</li>			     
		         <li class='submenu'> 
			     <a href='#'>
			       <i class="glyphicon glyphicon-list"></i> Student
			       <span class="caret pull-right"></span>
			     </a>
		             <ul>
		                <li><a href="student_registration.php"> Register Student </a></li>
		                <li><a href="student_class.php"> List of Students </a></li>
				<li><a href="student_information.php"> Print Students List </a></li>		                
		            </ul>
		         </li>
		          <li class='submenu'>
			     <a href='#'>
			        <i class="glyphicon glyphicon-user"></i> Teacher
				<span class="caret pull-right"></span>
			     </a>
		             <ul>
		    	       <li><a href="teacher_registration.php"> Register Teacher </a></li>
		    	       <li><a href="class_teacher.php"> List of Teachers </a></li>
		             </ul>
		          </li> 
			  <li class='submenu'> 
			     <a href='#'>
			        <i class="glyphicon glyphicon-link"></i> Class
			  	<span class="caret pull-right"></span>
			     </a>
			    <ul>
			  	<li><a href="add_class.php"> Add Classroom </a></li>
			  	<li><a href="view_class.php"> List of Classrooms </a></li>
			    </ul>
			  </li>				  			  
			<li><a href="ann_add.php"><i class="glyphicon glyphicon-bullhorn"></i> Announcement </a></li>
		</ul>
             </div>
	</div>
	
	<div class="col-md-9">
	   <div class="row">
	      <div class="container-fluid">
	   	<div class="panel panel-primary">
	          <div class="panel-heading"><center><b>LIST OF TIMETABLE</b></center></div>
		  
		  <br/><br/>
		  
		<!-- Modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		   <div class="modal-dialog">
		      <div class="modal-content">
			   <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Confirmation</h4>
			   </div>
			  <div class="modal-body">
				Are you to sure you want to delete this?
			  </div>
			  <div class="modal-footer">
			  <form method = "POST">
			      <input type="submit" name="delete" value = "Delete" class="btn btn-danger">
				    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			   </div>
			</div>
		     </div>
		</div>
		<?php
		if(isset($_POST['delete']))
		{
		    $id=$_POST['selector'];
		    $N = count($id);
		    for($i=0; $i < $N; $i++)
		    {
			$result = mysql_query("DELETE FROM timetable where upload_id='$id[$i]'");
		    }
		}
		?>
		
		<!-- block -->						
	        <div id="block_bg" class="block">	
		    <div class="navbar navbar-inner block-header">
			<br/>
			&nbsp;&nbsp;&nbsp;<button type='button' class="btn btn-danger" data-toggle='modal' data-target='#myModal'><i class="glyphicon glyphicon-trash"></i></button>
				<a button type='button' class="btn btn-primary" href="upload_timetable.php">Upload Fail Baru</a>
		   </div>
			
	    	    <div class="panel-body">
		      <table class="table table-bordered">
		        <thead>
		          <tr>
			    <td></td>
		            <td><center>File Name</center></td>
		            <td><center>File Type</center></td>
		            <td><center>File Size (KB)</center></td>
		            <td><center>View</center></td>
			  </tr>
			</thead>
			
			<tbody>

			<?php 
			$sql="SELECT * FROM timetable";
			$result_set=mysql_query($sql);
			while($row=mysql_fetch_array($result_set))
			{
			    $id = $row['upload_id'];
		       ?>
		       
                       <tr>
			 <td width="30">
			   <input id="optionsCheckbox" class="uniform_on" name="selector[]" type="checkbox" value="<?php echo $id; ?>"/>
			 </td>		       
                         <td><center><?php echo $row['file'] ?></center></td>
                         <td><center><?php echo $row['type'] ?></center></td>
                         <td><center><?php echo $row['size'] ?></center></td>
                         <td><center><a href="upload/<?php echo $row['file'] ?>" target="_blank"> view file </a></center></td>
                      </tr>
                     <?php
	             }
	             ?>
		     
		     </tbody>
	          </table>
	        </div>
              </div>
            </div>		    
	  </div>
        </div>
      </div>
    </div>
</div>

 
<footer>
  <div class="container">
    <div class="copy text-center"> Copyright &copy; 2018 Bright Kindergarten </div>
  </div>
</footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../design/bootstrap/js/bootstrap.min.js"></script>
    <script src="../design/js/custom.js"></script>
  </body>
</html>				