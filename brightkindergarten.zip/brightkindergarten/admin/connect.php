<?php
//this file contain the database access information
//make the connection.
$dbc = mysql_connect ('localhost', 'root', '')
OR die ('could not connect to MySql:'. mysql_error() );

//select the database.
mysql_select_db('brightkindergarten')
OR die ('could not select the database:'. mysql_error() );
?>