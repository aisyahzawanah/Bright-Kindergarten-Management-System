<?php
session_start();

if (!empty($_SESSION['admin_name'])) 
{
    header('location:home.php');
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link rel="stylesheet" href="login_style.css" type="text/css"/>
</head>
<body>

<br/>
<br/>

<!-- Main Container -->
<div class="main_wrapper">

<div class="header_wrapper">
    <img src="logos.png" width="1000" height="60" align="center"/>
</div>
	
			<?php
	
				//php code we use to display the error message
				if (!empty($_GET['error'])) 
				{
	  			    if ($_GET['error'] == 1) 
	  			    {
					print '<script type="text/javascript">'; 
					print 'alert("Username and Password not been filled!")'; 
					print '</script>';  
	   			    } 
	   		 	    else if ($_GET['error'] == 2) 
	    			    {
	      				  echo '<h2 align="center">Username not been filled!</h2>';
	    			    } 
	   			    else if ($_GET['error'] == 3) 
	   			    {
					  echo '<h2 align="center">Password not been filled!</h2>';
	   			    } 
	   			    else if ($_GET['error'] == 4) 
	   			    {
				       	  echo '<h2 align="center">Username and Password is not registered!</h2>';
	   			    }
				}
  		?>
		  
<div id="login">
   <form name="login" action="auto.php" method="post">
   
    <div class="row">
       <div class="col-md-12">
         <div class="login well well-sm">
             <img src="sek.png" width="200" height="200" align="center" alt="logo" /> 
           </div>  
   
        <span class="fontawesome-user"></span>
          <input type="text" id="admin" name="admin_name" placeholder="admin name"/>
        <span class="fontawesome-lock"></span>
          <input type="password" id="password" name="password" placeholder="Password"/>
              <input type="submit" value="Login"/>
</form>
</div>
</div>
</div>
</div>
</html>